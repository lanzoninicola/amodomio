export const mongoUri = process.env.ATLAS_MONGO_URI;
export const mongoDbName = process.env.ATLAS_MONGO_DBNAME;
