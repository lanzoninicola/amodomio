export default function SingleMenuItemVendaHistorico() {


    return <div>SingleMenuItemVendaHistorico</div>
}