import { Outlet } from "@remix-run/react";



export default function AdminGerenciamentoCalendarioLayout() {
  return (
    <Outlet />
  )
}