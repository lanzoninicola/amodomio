

export default function AdminKdsIndex() {
  return (
    <div>admin kds index</div>
  )
}