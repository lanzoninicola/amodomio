import { Await, useActionData, useLoaderData, useFetcher, useFetcher as useCellFetcher, defer } from "@remix-run/react";
import { Suspense, useEffect, useMemo, useRef, useState } from "react";
import { toast } from "~/components/ui/use-toast";
import Loading from "~/components/loading/loading";
import { MenuItemWithSellPriceVariations, SellPriceVariation } from "~/domain/cardapio/menu-item.types";
import { cn } from "~/lib/utils";
import formatDecimalPlaces from "~/utils/format-decimal-places";
import { MenuItemsFilters } from "~/domain/cardapio/components/menu-items-filters/menu-items-filters";
import AlertsCostsAndSellPrice from "~/domain/cardapio/components/alerts-cost-and-sell-price/alerts-cost-and-sell-price";
import { MoneyInput } from "~/components/money-input/MoneyInput";
import { LoaderFunctionArgs, ActionFunctionArgs } from "@remix-run/node";
import { ok, badRequest } from "~/utils/http-response.server";

import prismaClient from "~/lib/prisma/client.server";
import { authenticator } from "~/domain/auth/google.server";
import { menuItemSellingPriceHandler } from "~/domain/cardapio/menu-item-selling-price-handler.server";
import { menuItemSizePrismaEntity } from "~/domain/cardapio/menu-item-size.entity.server";
import toFixedNumber from "~/utils/to-fixed-number";
import { prismaIt } from "~/lib/prisma/prisma-it.server";
import { menuItemSellingPriceUtilityEntity } from "~/domain/cardapio/menu-item-selling-price-utility.entity";
import { MenuItemSellingPriceVariationUpsertParams, menuItemSellingPriceVariationPrismaEntity } from "~/domain/cardapio/menu-item-selling-price-variation.entity.server";
import createUUID from "~/utils/uuid";
import { MenuItemSellingPriceVariationAudit } from "@prisma/client";
import { Button } from "~/components/ui/button";

// ======= LOADER =======
export async function loader({ request, params }: LoaderFunctionArgs) {
  const sellingChannelKey = params.channel as string;

  const currentSellingChannel = await prismaClient.menuItemSellingChannel.findFirst({
    where: { key: sellingChannelKey },
  });

  if (!currentSellingChannel) {
    return badRequest(`Can not find selling channel with key ${sellingChannelKey}`);
  }

  const menuItemsWithSellPriceVariations = menuItemSellingPriceHandler.loadMany({
    channelKey: currentSellingChannel.key,
  });

  const user = authenticator.isAuthenticated(request);

  const menuItemGroups = prismaClient.menuItemGroup.findMany({
    where: { deletedAt: null, visible: true },
  });

  const menuItemCategories = prismaClient.category.findMany({
    where: { type: "menu" },
  });

  const sizes = menuItemSizePrismaEntity.findAll();

  const returnedData = Promise.all([
    menuItemsWithSellPriceVariations,
    user,
    currentSellingChannel,
    menuItemGroups,
    menuItemCategories,
    sizes,
  ]);

  return defer({ returnedData });
}

// ======= ACTION (compatível com o form original) =======
export async function action({ request }: ActionFunctionArgs) {
  const formData = await request.formData();
  const { _action, ...values } = Object.fromEntries(formData);

  if (_action === "upsert-by-user-input") {
    // mesmos campos já usados no form original:contentReference[oaicite:2]{index=2}
    const menuItemSellPriceVariationId = values?.menuItemSellPriceVariationId as string;
    const menuItemSellingChannelId = values?.menuItemSellingChannelId as string;
    const menuItemSizeId = values?.menuItemSizeId as string;
    const menuItemId = values?.menuItemId as string;

    const priceAmount = toFixedNumber(values?.priceAmount, 2) || 0;

    const recipeCostAmount = toFixedNumber(values?.recipeCostAmount, 2) || 0;
    const packagingCostAmount = toFixedNumber(values?.packagingCostAmount, 2) || 0;
    const doughCostAmount = toFixedNumber(values?.doughCostAmount, 2) || 0;
    const wasteCostAmount = toFixedNumber(values?.wasteCostAmount, 2) || 0;
    const sellingPriceExpectedAmount = toFixedNumber(values?.sellingPriceExpectedAmount, 2) || 0;
    const profitExpectedPerc = toFixedNumber(values?.profitExpectedPerc, 2) || 0;

    const discountPercentage = isNaN(Number(values?.discountPercentage)) ? 0 : Number(values?.discountPercentage);
    const showOnCardapio = values?.showOnCardapio === "on" ? true : false;
    const updatedBy = (values?.updatedBy as string) || "";

    const dnaPerc = (await menuItemSellingPriceUtilityEntity.getSellingPriceConfig()).dnaPercentage || 0;

    const profitActualPerc = menuItemSellingPriceUtilityEntity.calculateProfitPercFromSellingPrice(
      priceAmount,
      {
        fichaTecnicaCostAmount: recipeCostAmount,
        packagingCostAmount,
        doughCostAmount,
        wasteCostAmount,
      },
      dnaPerc
    );

    const nextPrice: MenuItemSellingPriceVariationUpsertParams = {
      menuItemId,
      menuItemSellingChannelId,
      menuItemSizeId,
      priceAmount,
      priceExpectedAmount: sellingPriceExpectedAmount,
      profitActualPerc,
      profitExpectedPerc,
      discountPercentage,
      showOnCardapio,
      updatedBy,
      showOnCardapioAt: null,
    };

    const [err, result] = await prismaIt(
      menuItemSellingPriceVariationPrismaEntity.upsert(menuItemSellPriceVariationId, nextPrice)
    );

    if (!result) return badRequest(`Não foi possível atualizar o preço de venda`);

    // AUDIT
    const nextPriceAudit: MenuItemSellingPriceVariationAudit = {
      id: createUUID(),
      menuItemId,
      menuItemSellingChannelId,
      menuItemSizeId,
      doughCostAmount,
      packagingCostAmount,
      recipeCostAmount,
      wasteCostAmount,
      sellingPriceExpectedAmount,
      profitExpectedPerc,
      sellingPriceActualAmount: priceAmount,
      profitActualPerc,
      dnaPerc,
      updatedBy,
      createdAt: new Date(),
      updatedAt: new Date(),
    };

    const [errAudit] = await prismaIt(
      prismaClient.menuItemSellingPriceVariationAudit.create({ data: nextPriceAudit })
    );

    if (err || errAudit) return badRequest(err || errAudit || `Não foi possível atualizar o preço de venda`);

    return ok(`O preço de venda foi atualizado com sucesso`);
  }

  return ok("Elemento atualizado com successo");
}

// ======= UI NOVA: TABELA DE EDIÇÃO INLINE =======
type SizeLite = { id: string; key: string; name: string };

export default function AdminGerenciamentoCardapioSellPriceManagementSingleChannelEdit() {
  const { returnedData } = useLoaderData<typeof loader>();
  const actionData = useActionData<typeof action>();
  const fetcher = useFetcher();

  useEffect(() => {
    if (!actionData) return;
    if (actionData.status > 399) {
      toast({ title: "Erro", description: actionData.message });
    } else if (actionData.status === 200) {
      toast({ title: "Ok", description: actionData.message });
    }
  }, [actionData]);

  useEffect(() => {
    if (fetcher.data?.status > 399) {
      toast({ title: "Erro", description: fetcher.data?.message || "Falha ao salvar" });
    }
    if (fetcher.data?.status === 200) {
      toast({ title: "Salvo", description: fetcher.data?.message || "Preço atualizado" });
    }
  }, [fetcher.data]);

  return (
    <Suspense fallback={<Loading />}>
      <Await resolve={returnedData}>
        {/* @ts-ignore */}
        {([menuItemsWithSellPriceVariations, user, currentSellingChannel, groups, categories, sizes]) => {
          const [items, setItems] = useState<MenuItemWithSellPriceVariations[]>(
            menuItemsWithSellPriceVariations || []
          );

          const sizeColumns: SizeLite[] = useMemo(
            () =>
              (sizes || []).map((s: any) => ({
                id: s.id,
                key: s.key,
                name: s.name,
              })),
            [sizes]
          );

          const priceCellClass = (record?: SellPriceVariation) => {
            if (!record) return "";
            const minWithProfit =
              record.computedSellingPriceBreakdown?.minimumPrice?.priceAmount.withProfit ?? 0;
            const minBreakEven =
              record.computedSellingPriceBreakdown?.minimumPrice?.priceAmount.breakEven ?? 0;
            const p = record.priceAmount ?? 0;
            if (p > 0 && minBreakEven > p) return "bg-red-100";
            if (p > 0 && minWithProfit > p) return "bg-orange-100";
            return "bg-transparent";
          };

          const getVariation = (menuItem: MenuItemWithSellPriceVariations, sizeId: string) =>
            menuItem.sellPriceVariations.find((sv) => sv.sizeId === sizeId);

          // ===== CÉLULA EDITÁVEL COM BOTÕES =====
          const EditablePriceCell = ({
            menuItem,
            size,
          }: {
            menuItem: MenuItemWithSellPriceVariations;
            size: SizeLite;
          }) => {
            const variation = getVariation(menuItem, size.id);
            const formRef = useRef<HTMLFormElement>(null);
            const cellFetcher = useCellFetcher();

            useEffect(() => {
              if (cellFetcher.data?.status > 399) {
                toast({ title: "Erro", description: cellFetcher.data?.message || "Falha ao salvar" });
              }
              if (cellFetcher.data?.status === 200) {
                toast({ title: "Salvo", description: cellFetcher.data?.message || "Preço atualizado" });
              }
            }, [cellFetcher.data]);

            if (!variation) {
              return <div className="text-[12px] text-muted-foreground text-center">—</div>;
            }

            const cspb = variation.computedSellingPriceBreakdown;
            const rec = Number(cspb?.minimumPrice?.priceAmount.withProfit ?? 0); // recomendado:contentReference[oaicite:3]{index=3}
            const margemAlvo = Number(cspb?.channel?.targetMarginPerc ?? 0);     // alvo %:contentReference[oaicite:4]{index=4}
            const anterior = variation.previousPriceAmount ?? 0;                  // preço anterior:contentReference[oaicite:5]{index=5}
            const atual = variation.priceAmount ?? 0;                             // preço atual:contentReference[oaicite:6]{index=6}:contentReference[oaicite:7]{index=7}

            const submitForm = () => {
              if (!formRef.current) return;
              const fd = new FormData(formRef.current);
              // garante o _action correto esperado pelo action:contentReference[oaicite:8]{index=8}
              fd.set("_action", "upsert-by-user-input");
              cellFetcher.submit(fd, { method: "post" });
            };

            const applyRecommended = () => {
              if (!formRef.current) return;
              const fd = new FormData(formRef.current);
              fd.set("_action", "upsert-by-user-input");
              fd.set("priceAmount", String(rec));
              cellFetcher.submit(fd, { method: "post" });
            };

            // (opcional) ainda permite autosave no blur/Enter
            const onBlurAutoSave: React.FocusEventHandler<HTMLInputElement> = (e) => {
              const newVal = e.currentTarget.value;
              if (!formRef.current) return;
              const fd = new FormData(formRef.current);
              if (fd.get("priceAmount")?.toString() === String(atual)) return; // evita submit igual
              fd.set("_action", "upsert-by-user-input");
              cellFetcher.submit(fd, { method: "post" });
            };

            const onEnterAutoSave = (e: React.KeyboardEvent<HTMLInputElement>) => {
              if (e.key === "Enter") {
                e.preventDefault();
                submitForm();
              }
            };

            return (
              <div className={cn("px-2 py-2 rounded", priceCellClass(variation))}>
                <div className="flex gap-3 items-center justify-center mb-1">
                  <span className="text-[10px] uppercase text-center  tracking-wider">
                    {variation.sizeName}
                  </span>
                  {/* Preço atual */}
                  <div className="text-center">
                    <span className="text-[11px] font-mono">
                      R$ {formatDecimalPlaces(atual || 0)}
                    </span>
                  </div>

                </div>

                {/* Form específico da célula, sem navegação (useFetcher.Form) */}
                <cellFetcher.Form ref={formRef} method="post" className="flex flex-col gap-0">
                  {/* IDs e metadados exigidos pelo action — mesmos nomes do form original:contentReference[oaicite:9]{index=9} */}
                  <input type="hidden" name="_action" value="upsert-by-user-input" />
                  <input type="hidden" name="menuItemId" value={menuItem.menuItemId} />
                  <input type="hidden" name="menuItemSellPriceVariationId" value={variation.menuItemSellPriceVariationId ?? ""} />
                  <input type="hidden" name="menuItemSellingChannelId" value={currentSellingChannel.id ?? ""} />
                  <input type="hidden" name="menuItemSizeId" value={variation.sizeId ?? ""} />
                  <input type="hidden" name="updatedBy" value={variation.updatedBy || user?.email || ""} />
                  {/* custos e parâmetros para cálculo no action:contentReference[oaicite:10]{index=10} */}
                  <input type="hidden" name="recipeCostAmount" value={cspb?.custoFichaTecnica ?? 0} />
                  <input type="hidden" name="packagingCostAmount" value={cspb?.packagingCostAmount ?? 0} />
                  <input type="hidden" name="doughCostAmount" value={cspb?.doughCostAmount ?? 0} />
                  <input type="hidden" name="wasteCostAmount" value={cspb?.wasteCost ?? 0} />
                  <input type="hidden" name="sellingPriceExpectedAmount" value={cspb?.minimumPrice?.priceAmount.withProfit ?? 0} />
                  <input type="hidden" name="profitExpectedPerc" value={cspb?.channel?.targetMarginPerc ?? 0} />
                  {/* compat / defaults */}
                  <input type="hidden" name="discountPercentage" value="0" />
                  {variation.showOnCardapio && <input type="hidden" name="showOnCardapio" value="on" />}

                  <div className="grid grid-cols-2 items-center">
                    {/* Campo editável */}
                    <MoneyInput
                      name="priceAmount"
                      defaultValue={variation.priceAmount}
                      onBlur={onBlurAutoSave}
                      onKeyDown={onEnterAutoSave}
                      className="font-mono"
                    />

                    {/* Botão SALVAR explícito */}
                    <div className="mt-2">
                      <Button
                        variant={"outline"}
                        size={"sm"}
                        onClick={submitForm}
                        className="font-neue w-full rounded border text-[11px] uppercase tracking-widest border-slate-800"
                        title="Salvar preço"
                        disabled={cellFetcher.state !== "idle"}
                      >
                        {cellFetcher.state === "idle" ? "Salvar" : "Salvando..."}
                      </Button>
                    </div>
                  </div>


                  {/* Recomendado + botão aplicar */}
                  <div className="mt-1 flex items-center justify-between gap-1">
                    <span className="text-[10px] text-muted-foreground">
                      {`Val. rec. (lucro ${margemAlvo}%)`}
                    </span>
                    <button
                      type="button"
                      className="text-[11px] font-mono rounded px-1.5 py-0.5 bg-slate-100 hover:bg-slate-200"
                      onClick={applyRecommended}
                      title="Aplicar recomendado"
                    >
                      {`R$ ${formatDecimalPlaces(rec)}`}
                    </button>
                  </div>

                  {/* Preço anterior */}
                  <div className="text-[10px] text-muted-foreground">
                    {`Anterior: R$ ${formatDecimalPlaces(anterior || 0)}`}
                  </div>


                </cellFetcher.Form>
              </div>
            );
          };

          return (
            <div className="flex flex-col gap-3">
              {/* Filtros + Alertas */}
              <div className="flex flex-col gap-2 py-2 md:py-0 md:grid md:grid-cols-8 md:items-center mb-2 bg-slate-50 px-1">
                <MenuItemsFilters
                  initialItems={menuItemsWithSellPriceVariations}
                  groups={groups}
                  categories={categories}
                  onItemsChange={(filtered: MenuItemWithSellPriceVariations[]) => setItems(filtered)}
                  cnContainer="col-span-7"
                />
                <AlertsCostsAndSellPrice items={items} cnContainer="col-span-1 flex justify-center md:justify-end w-full" />
              </div>

              {/* Tabela */}
              <div className="overflow-auto rounded-md border">
                <table className="w-full text-sm">
                  <thead className="sticky top-0 bg-white border-b">
                    <tr>
                      <th className="text-left px-3 py-2 w-[260px]">Sabor ({currentSellingChannel.name})</th>
                      {sizeColumns.map((sz) => (
                        <th key={sz.id} className="text-center px-2 py-2 min-w-[190px]">
                          {sz.name}
                        </th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {items.map((mi) => (
                      <tr key={mi.menuItemId} className="border-b hover:bg-slate-50">
                        <td className="px-3 py-3 align-top">
                          <div className="flex flex-col">
                            <span className="font-semibold">{mi.name}</span>
                            <span className="text-[11px] text-muted-foreground">
                              ID: {mi.menuItemId.slice(0, 8)}…
                            </span>
                          </div>
                        </td>
                        {sizeColumns.map((sz) => (
                          <td key={sz.id} className="px-2 py-2 align-top">
                            <EditablePriceCell menuItem={mi} size={sz} />
                          </td>
                        ))}
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          );
        }}
      </Await>
    </Suspense>
  );
}
