

export default function AdminGerenciamentoCardapioCostManagementSettings() {
  return (
    <div className="flex flex-col gap-4">
      <h1 className="text-2xl font-bold">Configurações de custo</h1>
      <p className="text-sm text-muted-foreground">Gerencie as configurações de custo do cardápio.</p>
    </div>
  )
}