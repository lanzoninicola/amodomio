import WorkInProgress from "~/components/primitives/work-in-progress/work-in-progress";





export default function SingleProductPricing() {

    return <WorkInProgress />
}