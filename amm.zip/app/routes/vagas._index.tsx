


export default function VagasIndex() {


    return <div>Lista das vagas disponiveis</div>
}