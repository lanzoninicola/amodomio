import { DOTProduct } from "./daily-order.model.server";

export default function dotProducts(): DOTProduct[] {
  return ["Pizza Familía", "Pizza Média", "Al Taglio", "Bebida"];
}
