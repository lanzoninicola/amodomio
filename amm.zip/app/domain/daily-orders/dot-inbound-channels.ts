import { DOTInboundChannel } from "./daily-order.model.server";

const dotInboundChannels = (): DOTInboundChannel[] => ["Mogo", "Aiqfome"];

export default dotInboundChannels;
