import { Form, useActionData,  } from "@remix-run/react";
import { useTransition } from "react";
import SubmitButton from "~/components/primitives/submit-button/submit-button";
import { Input } from "~/components/ui/input";

export default function DnaEmpresaForm() {

}
