import CategoriesTabs from "./categories-tabs/categories-tabs";

export { CategoriesTabs };
