



export default function CartFooter() {

    return (
        <div className="absolute bottom-4">

        </div>
    )
}