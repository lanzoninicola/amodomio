import FormLabel from "./form-label/form-label";

export { FormLabel };
